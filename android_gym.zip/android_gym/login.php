<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header('Content-Type: application/json');
include 'db_connect.php';

// Check if POST data exists
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Fetch POST data
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    // Validate input (optional, but recommended)
    $email = mysqli_real_escape_string($conn, $email);
    $password = mysqli_real_escape_string($conn, $password);

    // SQL query to validate login
    $sql = "SELECT * FROM admin WHERE email='$email' AND password='$password'";
    $result = $conn->query($sql);

    if ($result) {
        if ($result->num_rows > 0) {
            // Login successful
            $row = $result->fetch_assoc();
            $response = array(
                'status' => 'success',
                'message' => 'Login successful',
                'data' => $row
            );
        } else {
            // Login failed
            $response = array(
                'status' => 'error',
                'message' => 'Invalid email or password'
            );
        }
    } else {
        // Error in SQL query
        $response = array(
            'status' => 'error',
            'message' => 'Error executing SQL query'
        );
    }

    echo json_encode($response);
} else {
    // Invalid request method
    echo json_encode(array('status' => 'error', 'message' => 'Invalid request method'));
}

// Close database connection
$conn->close();
?>
