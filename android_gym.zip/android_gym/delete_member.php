<?php
include 'db_connect.php';

$id = $_POST['id'];

$sql = "DELETE FROM members WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    $response = array("status" => "success", "message" => "Record deleted successfully");
} else {
    $response = array("status" => "error", "message" => "Error deleting record: " . $conn->error);
}

echo json_encode($response);
$conn->close();
?>
