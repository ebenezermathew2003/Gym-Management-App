<?php
// member_login.php
require '../db_connect.php'; // Adjust relative path based on actual directory structure

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    $stmt = $conn->prepare("SELECT * FROM members WHERE email = ? AND phone = ?");
    $stmt->bind_param("ss", $email, $phone);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $response = array('status' => 'success', 'message' => 'Login successful');
    } else {
        $response = array('status' => 'error', 'message' => 'Invalid email or mobile number');
    }

    echo json_encode($response);
}
?>
