<?php
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    
    
    error_log("Received ID: " . $id);

    $sql = "DELETE FROM announcements WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        echo "Announcement deleted successfully";
    } else {
        
        error_log("Error: " . $sql . " - " . $conn->error);
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
} else {
    echo "Invalid request method";
}
?>
