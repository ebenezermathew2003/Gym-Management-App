<?php
include 'db_connect.php';

$number = $_POST['number'];
$name = $_POST['name'];
$amount = $_POST['amount'];
$quantity = $_POST['quantity'];
$purchase_date = $_POST['purchase_date'];

$sql = "INSERT INTO equipment (number, name, amount, quantity, purchase_date) VALUES ('$number', '$name', '$amount', '$quantity', '$purchase_date')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
