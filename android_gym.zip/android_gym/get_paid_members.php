<?php
include 'db_connect.php';

$sql = "SELECT * FROM payments WHERE payment_completed = 'Yes'";
$result = $conn->query($sql);

$paid_members = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $paid_members[] = $row;
    }
}

echo json_encode($paid_members);

$conn->close();
?>
