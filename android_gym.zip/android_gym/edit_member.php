<?php
include 'db_connect.php';

$id = $_POST['id'];
$name = $_POST['name'];
$age = $_POST['age'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$health_status = $_POST['health_status'];
$plan = $_POST['plan'];

$sql = "UPDATE members SET name='$name', age='$age', email='$email', phone='$phone', health_status='$health_status', plan='$plan' WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    $response = array("status" => "success", "message" => "Record updated successfully");
} else {
    $response = array("status" => "error", "message" => "Error updating record: " . $conn->error);
}

echo json_encode($response);
$conn->close();
?>
