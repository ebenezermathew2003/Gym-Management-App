<?php
include 'db_connect.php';

// Assuming you want to fetch all progress data for all members
$stmt = $conn->prepare("SELECT * FROM member_progress");

if ($stmt->execute()) {
    $result = $stmt->get_result();
    $progressData = $result->fetch_all(MYSQLI_ASSOC);
    echo json_encode(array('status' => 'success', 'data' => $progressData));
} else {
    echo json_encode(array('status' => 'error', 'message' => 'Failed to fetch progress data.'));
}

$stmt->close();
$conn->close();
?>
