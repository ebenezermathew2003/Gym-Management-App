<?php
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $member_fullname = $_POST['member_fullname'];
    $date_of_last_payment = $_POST['date_of_last_payment'];
    $amount_per_month = $_POST['amount_per_month'];
    $selected_service = $_POST['selected_service'];
    $plan = $_POST['plan'];
    $total_amount = $_POST['total_amount'];
    $payment_completed = $_POST['payment_completed'];

    $sql = "INSERT INTO payments (member_fullname, date_of_last_payment, amount_per_month, selected_service, plan, total_amount, payment_completed)
            VALUES ('$member_fullname', '$date_of_last_payment', $amount_per_month, '$selected_service', $plan, $total_amount, '$payment_completed')";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(["status" => "success", "message" => "Payment saved successfully"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Error: " . $sql . "<br>" . $conn->error]);
    }

    $conn->close();
}
?>
