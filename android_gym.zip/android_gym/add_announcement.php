<?php
include 'db_connect.php';

header('Content-Type: application/json'); // Set content type to JSON

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get POST parameters
    $date = $_POST['date'] ?? '';
    $message = $_POST['message'] ?? '';

    // Check if the parameters are not empty
    if (empty($date) || empty($message)) {
        echo json_encode(['error' => 'Date and message are required']);
        exit;
    }

    // Prepare the SQL statement
    $stmt = $conn->prepare("INSERT INTO announcements (date, message) VALUES (?, ?)");
    if (!$stmt) {
        echo json_encode(['error' => 'SQL prepare error: ' . $conn->error]);
        exit;
    }

    // Bind parameters and execute the statement
    $stmt->bind_param('ss', $date, $message);

    if ($stmt->execute()) {
        echo json_encode(['success' => 'New announcement created successfully']);
    } else {
        echo json_encode(['error' => 'SQL execute error: ' . $stmt->error]);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>
