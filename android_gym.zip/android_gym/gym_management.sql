-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 27, 2024 at 11:55 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gym_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `password`) VALUES
(1, '4al21cs039@gmail.com', 'Mathew'),
(2, 'Ganesh@gmail.com', 'admin'),
(3, '123@gmail.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(11) NOT NULL,
  `date` varchar(255) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `date`, `message`) VALUES
(1, '10/11/2024', 'hi'),
(2, '1234', 'helloooo'),
(3, '2142', 'helllll'),
(4, '214', 'rter'),
(5, '11/12/2002', 'hello'),
(6, '2024-10-20', 'There is holiday for gym tomorrow'),
(7, '24/12/2021', 'the announcement');

-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

CREATE TABLE `equipment` (
  `id` int(11) NOT NULL,
  `number` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `amount` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `purchase_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `equipment`
--

INSERT INTO `equipment` (`id`, `number`, `name`, `amount`, `quantity`, `purchase_date`) VALUES
(3, 121, 'matplotlib', 4500, 5, '2024-07-02'),
(5, 2, 'fsf', 12, 123, '2024-07-24'),
(6, 3, 'Mat', 200, 20, '2024-07-17');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `health_status` varchar(255) NOT NULL,
  `plan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `name`, `age`, `email`, `phone`, `health_status`, `plan`) VALUES
(38, 'dvsd ', 13, 'dasf', '13435475', 'good', '3'),
(40, 'Ebenezer', 21, 'mathew@gmail.com', '9902334713', 'bad', '2 '),
(44, 'gane', 123, 'gane@gmail.com', '23456', 'good', '2'),
(46, 'kallesh', 21, 'kallesh@gmail.com', '123456789', 'good', '2'),
(47, 'Daniel', 6, 'dani@gmail.com', '9902604134', 'good', '4'),
(49, 'Indu', 21, 'indu@gmail.com', '7795113686', 'good', '0');

-- --------------------------------------------------------

--
-- Table structure for table `member_payments`
--

CREATE TABLE `member_payments` (
  `id` int(11) NOT NULL,
  `member_fullname` varchar(255) NOT NULL,
  `date_of_last_payment` date DEFAULT NULL,
  `amount_per_month` decimal(10,2) DEFAULT NULL,
  `selected_service` varchar(50) DEFAULT NULL,
  `plan` int(11) DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `payment_completed` enum('Yes','No') DEFAULT 'No',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `member_payments`
--

INSERT INTO `member_payments` (`id`, `member_fullname`, `date_of_last_payment`, `amount_per_month`, `selected_service`, `plan`, `total_amount`, `payment_completed`, `created_at`) VALUES
(1, 'Ebenezer', '2024-12-25', 25.00, 'Leg', 6, 150.00, '', '2024-07-21 13:50:48'),
(3, 'Daniel', '2024-10-25', 50.00, 'Leg', 3, 150.00, '', '2024-07-21 14:22:26'),
(6, 'Daniel', '2024-02-20', 200.00, 'Leg', 4, 800.00, '', '2024-07-21 15:56:34'),
(7, 'Daniel', '2024-02-20', 200.00, 'Leg', 4, 800.00, '', '2024-07-21 15:56:40'),
(8, 'Daniel', '2024-02-20', 200.00, 'Leg', 4, 800.00, '', '2024-07-21 15:57:29'),
(9, 'Ebenezer', '2024-02-24', 1000.00, 'Muscle', 3, 3000.00, '', '2024-07-23 11:19:28');

-- --------------------------------------------------------

--
-- Table structure for table `member_progress`
--

CREATE TABLE `member_progress` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `current_weight` decimal(5,2) DEFAULT NULL,
  `current_body_type` varchar(50) DEFAULT NULL,
  `progress_notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `member_progress`
--

INSERT INTO `member_progress` (`id`, `member_id`, `current_weight`, `current_body_type`, `progress_notes`) VALUES
(2, 38, 20.00, 'flat', 'improve'),
(3, 38, 12.00, 'bould', 'hdgdhg'),
(4, 38, 85.00, 'bould', 'hdgdhg');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `member_fullname` varchar(255) NOT NULL,
  `date_of_last_payment` date NOT NULL,
  `amount_per_month` int(11) NOT NULL,
  `selected_service` varchar(255) NOT NULL,
  `plan` int(11) NOT NULL,
  `total_amount` int(11) NOT NULL,
  `payment_completed` enum('Yes','No') DEFAULT 'Yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `member_fullname`, `date_of_last_payment`, `amount_per_month`, `selected_service`, `plan`, `total_amount`, `payment_completed`) VALUES
(1, 'Ebenezer', '0000-00-00', 350, 'Muscle', 7, 2450, 'Yes'),
(6, 'Ebenezer', '2222-02-20', 10, 'Muscle', 5, 50, 'Yes'),
(7, 'Daniel', '2024-10-25', 50, 'Leg', 3, 150, 'Yes'),
(8, 'Daniel', '2024-02-20', 200, 'Leg', 4, 800, 'Yes'),
(9, 'Ebenezer', '2024-02-24', 1000, 'Muscle', 3, 3000, 'Yes');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `equipment`
--
ALTER TABLE `equipment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `member_payments`
--
ALTER TABLE `member_payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `member_progress`
--
ALTER TABLE `member_progress`
  ADD PRIMARY KEY (`id`),
  ADD KEY `member_id` (`member_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `equipment`
--
ALTER TABLE `equipment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `member_payments`
--
ALTER TABLE `member_payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `member_progress`
--
ALTER TABLE `member_progress`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `member_progress`
--
ALTER TABLE `member_progress`
  ADD CONSTRAINT `member_progress_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
