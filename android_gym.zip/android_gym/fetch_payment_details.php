<?php
include 'db_connect.php'; // Include the database connection file

// Get the GET parameters
$member_fullname = $_GET['member_fullname'] ?? '';

if (empty($member_fullname)) {
    echo json_encode(['error' => 'Member fullname is required']);
    exit;
}

// Prepare the SQL statement
$sql = "SELECT id, member_fullname, date_of_last_payment, amount_per_month, selected_service, plan, total_amount, payment_completed, created_at FROM member_payments WHERE member_fullname = ?";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode(['error' => 'SQL prepare error: ' . $conn->error]);
    exit;
}

$stmt->bind_param('s', $member_fullname);

// Execute the statement
if (!$stmt->execute()) {
    echo json_encode(['error' => 'SQL execute error: ' . $stmt->error]);
    exit;
}

$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $paymentDetails = $result->fetch_assoc();
    echo json_encode($paymentDetails);
} else {
    echo json_encode(['message' => 'No payment details found']);
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
