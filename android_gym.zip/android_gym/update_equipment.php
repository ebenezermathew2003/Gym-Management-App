<?php
include 'db_connect.php';

$id = $_POST['id'];
$number = $_POST['number'];
$name = $_POST['name'];
$amount = $_POST['amount'];
$quantity = $_POST['quantity'];
$purchase_date = $_POST['purchase_date'];

$sql = "UPDATE equipment SET number='$number', name='$name', amount='$amount', quantity='$quantity', purchase_date='$purchase_date' WHERE id='$id'";

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();
?>
