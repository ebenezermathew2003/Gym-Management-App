<?php
include 'db_connect.php';

$name = $_POST['name'];
$age = $_POST['age'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$health_status = $_POST['health_status'];
$plan = $_POST['plan'];

$sql = "INSERT INTO members (name, age, email, phone, health_status, plan) VALUES ('$name', '$age', '$email', '$phone', '$health_status', '$plan')";

if ($conn->query($sql) === TRUE) {
    $last_id = $conn->insert_id;
    $response = array("status" => "success", "message" => "New record created successfully", "id" => $last_id);
} else {
    $response = array("status" => "error", "message" => "Error: " . $sql . "<br>" . $conn->error);
}

echo json_encode($response);
$conn->close();
?>
