<?php
include 'db_connect.php';

$sql = "SELECT * FROM payments";
$result = $conn->query($sql);

$memberStatusList = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $memberStatusList[] = $row;
    }
}
echo json_encode($memberStatusList);

$conn->close();
?>
