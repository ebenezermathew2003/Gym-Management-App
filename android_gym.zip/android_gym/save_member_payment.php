<?php
include 'db_connect.php'; // Include the database connection file

// Get the POST data
$member_fullname = $_POST['member_fullname'] ?? '';
$date_of_last_payment = $_POST['date_of_last_payment'] ?? '';
$amount_per_month = $_POST['amount_per_month'] ?? '';
$selected_service = $_POST['selected_service'] ?? '';
$plan = $_POST['plan'] ?? '';
$total_amount = $_POST['total_amount'] ?? '';
$payment_completed = $_POST['payment_completed'] ?? '';

// Prepare the SQL statement to insert the data
$stmt = $conn->prepare("INSERT INTO member_payments (member_fullname, date_of_last_payment, amount_per_month, selected_service, plan, total_amount, payment_completed) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param('sssssii', $member_fullname, $date_of_last_payment, $amount_per_month, $selected_service, $plan, $total_amount, $payment_completed);

// Execute the statement and check if it was successful
if ($stmt->execute()) {
    $response = ['status' => 'success'];
} else {
    $response = ['status' => 'error', 'message' => $stmt->error];
}

// Close the statement and connection
$stmt->close();
$conn->close();

// Return the response as JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
