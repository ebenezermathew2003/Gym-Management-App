<?php
include 'db_connect.php';

$member_id = $_GET['member_id'];

$stmt = $conn->prepare("SELECT * FROM member_progress WHERE member_id = ?");
$stmt->bind_param("i", $member_id);

if ($stmt->execute()) {
    $result = $stmt->get_result();
    $progress = $result->fetch_all(MYSQLI_ASSOC);
    echo json_encode(array('status' => 'success', 'data' => $progress));
} else {
    echo json_encode(array('status' => 'error', 'message' => 'Failed to fetch progress.'));
}

$stmt->close();
$conn->close();
?>
