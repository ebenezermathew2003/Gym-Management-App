<?php
include 'db_connect.php';

$sql = "CREATE TABLE IF NOT EXISTS equipment (
    number INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    amount INT NOT NULL,
    quantity INT NOT NULL,
    date DATE NOT NULL
)";

if ($conn->query($sql) === TRUE) {
    echo "Table equipment created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
?>
