<?php
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $member_id = $_POST['member_id'];
    $current_weight = $_POST['current_weight'];
    $current_body_type = $_POST['current_body_type'];
    $progress_notes = $_POST['progress_notes'];

    $stmt = $conn->prepare("INSERT INTO member_progress (member_id, current_weight, current_body_type, progress_notes) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("idss", $member_id, $current_weight, $current_body_type, $progress_notes);

    if ($stmt->execute()) {
        $response = array('status' => 'success', 'message' => 'Progress updated successfully.');
    } else {
        $response = array('status' => 'error', 'message' => 'Failed to update progress.');
    }

    $stmt->close();
    $conn->close();

    echo json_encode($response);
}
?>
