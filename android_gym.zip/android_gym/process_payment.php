<?php
include 'db_connect.php'; // Include the database connection

// Retrieve POST data from the request
$member_fullname = $_POST['member_fullname'];
$date_of_last_payment = $_POST['date_of_last_payment'];
$amount_per_month = $_POST['amount_per_month'];
$selected_service = $_POST['selected_service'];
$plan = $_POST['plan'];
$total_amount = $_POST['total_amount'];
$payment_completed = $_POST['payment_completed'];

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO payments (member_fullname, date_of_last_payment, amount_per_month, selected_service, plan, total_amount, payment_completed) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssisis", $member_fullname, $date_of_last_payment, $amount_per_month, $selected_service, $plan, $total_amount, $payment_completed);

// Execute the query
if ($stmt->execute()) {
    echo json_encode(array('status' => 'success', 'message' => 'Payment saved successfully!'));
} else {
    echo json_encode(array('status' => 'error', 'message' => 'Failed to save payment.'));
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
