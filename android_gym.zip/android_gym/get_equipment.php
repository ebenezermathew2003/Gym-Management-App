<?php
header('Content-Type: application/json');
include 'db_connect.php';

$sql = "SELECT * FROM equipment";
$result = $conn->query($sql);

$equipment = array();
while($row = $result->fetch_assoc()) {
    $equipment[] = $row;
}

echo json_encode($equipment);

$conn->close();
?>
